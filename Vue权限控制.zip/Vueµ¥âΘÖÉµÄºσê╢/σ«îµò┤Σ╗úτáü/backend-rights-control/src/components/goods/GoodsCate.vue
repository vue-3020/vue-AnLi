<template>
  <div>
    <h3>商品分类</h3>
    <div>分类列表如下</div>
  </div>
</template>
